<template>
    <div>
        <ul>
            <li class="pagination-link" v-for="page in pages" :key="page" @click="$emit('onPageChange', {page: page, searchString: searchString})">{{ page}}</li>
        </ul>
    </div>
</template>

<script>
export default {
    name: 'Pagination',
    props: {
        pages: {
            required: true,
            type: Number,
            default: 1
        },
        searchString:{
           type: String
        }
    }
}
</script>

