<template>

<div>
    <div class="box">
 <p class="is-size-3 is-family-primary has-text-weight-bold">{{Title}}</p>
 <p class="">{{AuthorName}}</p>
 <p >{{calculateDate}}</p>
 <router-link :to="{ name: 'SpesificArticle', params: { id:Index}}">
 <button  class="button is-link">View</button>
    </router-link>
 <button @click="showEditModal()" class="button is-info">Edit</button>
 <button @click="deleteArticle(Index)" class="button is-danger">Delete</button>
 



</div>
</div>

</template>

<script>
import Modal from './modal.vue'
export default {
    props: {
        'Title' :String,
         'Author' : String,
         'DateCreated': Date,
         'DateUpdated': Date,
         'AuthorNumber' : Number,
         'Index': Number,

    },
  name: 'Articles',
  data () {
    return {
      articles: [],
      authors: [],
      AuthorName:'',
      computedData: '',
      isModalVisible: false
    }
  },
  components:{
    Modal
  },
  methods:{
    async getArticles(){
    const response = await this.$http.get("http://localhost:3000/Articles").then(res => {this.articles = res.data})
    
    },
    async getAuthors(){
    const response = await this.$http.get("http://localhost:3000/Authors").then(res => {this.authors = res.data})
    
    },
    async getAuthor(){
        const url = "http://localhost:3000/Authors/" + this.AuthorNumber
    const response = await this.$http.get(url).then(res => {this.AuthorName = res.data.name})
   
    },
     async deleteArticle(index){
      if(confirm("Do you really want to delete?")){
      this.$http.delete(`http://localhost:3000/Articles/${index}`).then(res => {this.$emit('delete-sucess')}).catch( err => {this.$emit('delete-fail')})
      }
      
    },
    showEditModal(){
      this.$emit("show-edit", this.Index)
        this.isModalVisible = true
      },
      closeModal(){
        this.isModalVisible = false;
      },

  },
  computed:{
      calculateDate(){
        return this.DateCreated.getTime() < this.DateUpdated.getTime() ? this.DateUpdated.toLocaleString() : this.DateCreated.toLocaleString()
      }

    },
  created(){
    this.getArticles()
    this.getAuthors()
    this.getAuthor()
   
  }

}

</script>