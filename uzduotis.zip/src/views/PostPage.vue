<template>
  <div>
    <div class="box has-background-primary is-size-1 is-family-primary">
      <h1>Post page</h1>
    </div>
    <div class="field is-grouped is-grouped-centered">
    <button @click="showModal()" class="button is-primary mb-5 mr-4">Add article</button>
    <div class="control">
    <input v-model="searchedValue" @input="searchForArticle" class="input" type="text" placeholder="Look for Article">
  </div>
  </div>
    <Modal v-if="isModalVisible" @close-after-action="closeModalAfterAction" @close="closeModal()" :is-active="isModalVisible" :actionType="this.actionType" :editIndex="this.editIndex"></Modal>
    <ActionMessage v-if="showUpdateMessage" :isActive="showUpdateMessage" :type="showActionType" :sucess="sucess" @close-action="closeActionModal()"></ActionMessage>
    <div class="field has-addons">
</div>


    <div v-if="!noArticles" class="tile is-ancestor">
     
      <div v-for="article in articles" :key="article.id" class="tile has-text-centered is-child is-parent">

        <Articles @delete-sucess="setDeleteSucessMessage" @delete-fail="setDeleteFailMessage" @show-edit="showEditModal" :Index="article.id" :Title="article.title" :DateCreated="new Date(article.created_at)"
          :DateUpdated="new Date(article.updated_at)" :AuthorNumber="article.author"></Articles>
      </div>
    </div>
    <div v-else class="notification is-danger "  >
      <button class="delete"></button>
      Currently there are no articles
    </div>
    <Pagination @onPageChange="handlePageChange" :pages="pagesCount" :searchString="searchedValue"></Pagination>
  </div>
</template>

<script>
document.addEventListener('DOMContentLoaded', () => {
  (document.querySelectorAll('.notification .delete') || []).forEach(($delete) => {
    const $notification = $delete.parentNode;

    $delete.addEventListener('click', () => {
      $notification.parentNode.removeChild($notification);
    });
  });
});
import Articles from '../Componnents/Articles.vue'
import Pagination from '../Componnents/pagination.vue'
import Modal from '../Componnents/modal.vue'
import ActionMessage from '../Componnents/ActionMessage.vue'
export default {
  name: 'postPage',
  components: {
    Articles,
    Pagination,
    Modal,
    ActionMessage,
  },
  data() {
    return {
      articles: [],
      authors: [],
      createdAtDate: '',
      pagesCount: 0,
      limit: 2,
      isModalVisible: false,
      editIndex: 0,
      actionType: "",
      noArticles: false,
      searchedValue: "",
      showUpdateMessage: false,
      showActionType: '',
      sucess: '',
    }
  },
  methods: {
    async getArticles(page) {
      let totalPages = page < 0 || !page ? 1 : page
      const response = await this.$http.get("http://localhost:3000/Articles?_page=" + totalPages + "&_limit=" + this.limit).catch(err => {this.noArticles = true})
      if(response.data.length > 0){
      this.articles = response.data
      this.countPages(parseInt(response.headers['x-total-count']))
      this.noArticles = false
      }
      else{
        this.countPages(parseInt(response.headers['x-total-count']))
        this.noArticles = true
      }
      
    },
    async getSearchArticles(page,searchString) {
      let totalPages = page < 0 || !page ? 1 : page
      const response = await this.$http.get(`http://localhost:3000/Articles?_page=${totalPages}&_limit=${this.limit}&q=${searchString}`).catch(err => {this.noArticles = true})
      if(response.data.length > 0){
      this.articles = response.data
      this.countPages(parseInt(response.headers['x-total-count']))
      this.noArticles = false
      }
      else{
        this.noArticles = true
        this.countPages(parseInt(response.headers['x-total-count']))
      }
      
    },
    async getAuthors() {
      const response = await this.$http.get("http://localhost:3000/Authors")
      this.authors = response.data
    },

    countPages(postsNumber) {
      let pages = Math.ceil(postsNumber / this.limit)
      this.pagesCount = pages
    },
    handlePageChange(data) {
      if(data.page.length <= 0){
      this.getArticles(data.page)
      }
      else{
        this.getSearchArticles(data.page,data.searchString)
      }
    },
    showModal() {
        this.isModalVisible = true;
      },
      showEditModal(index){
         this.editIndex = index
         this.actionType = 'edit'
         this.isModalVisible = true;
      },
      closeModal() {
        this.isModalVisible = false;
        this.editIndex = -1
         this.actionType = ''
      },
      closeActionModal() {
        this.showUpdateMessage = false;
        if(this.showActionType == 'delete' && this.sucess == 'sucess'){
          this.$router.go(0);
        }
        this.showActionType = ''
      this.sucess = ''
      },
      closeModalAfterAction(data){
        this.isModalVisible = false;
        this.getArticles(1)
        this.editIndex = -1
      this.showActionType = data.type
      this.sucess = data.sucess
        this.showUpdateMessage = true
      },
      async searchForArticle(){
        if(this.searchedValue.length > 0){
        const response = await this.$http.get(`http://localhost:3000/Articles?q=${this.searchedValue}`)
        if(response.data.length <= 0){
          this.noArticles = true
        }
        this.articles = response.data
        this.getSearchArticles(1,this.searchedValue)
        }
        else{
          this.getArticles(1)
        }
      },
      setDeleteSucessMessage(){
        this.showActionType = 'delete'
      this.sucess = 'sucess'
        this.showUpdateMessage = true
      },
      setDeleteFailMessage(){
        this.showActionType = 'delete'
      this.sucess = 'failure'
        this.showUpdateMessage = true
      }

  },
  created() {
    this.getArticles(1)
    this.getAuthors()
  }
}
</script>
