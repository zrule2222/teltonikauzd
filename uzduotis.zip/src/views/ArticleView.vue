<template>
<div>
    <div class="box has-background-warning is-size-1 is-family-primary">
      <h1>Post details page</h1>
    </div>
    <div class="container">
        <section class="section">
            <div class="content is-medium">
<h1 class="title">{{ title }}</h1>
<h2 class="subtitle">{{ author }}</h2>
<p>{{ articleContent }}</p>
<p>{{ date }}</p>
<button @click="showEditModal()" class="button is-info">Edit</button>
 <button @click="deleteArticle($route.params.id)" class="button is-danger">Delete</button>
 <Modal v-if="isModalVisible" @close-after-action="closeModalAfterAction"  @close="closeModal()" :is-active="isModalVisible" :actionType="'edit'" :editIndex="parseInt(this.$route.params.id)"></Modal>
 <ActionMessage v-if="showUpdateMessage" :isActive="showUpdateMessage" :type="showActionType" :sucess="sucess" @close-action="closeActionModal()"></ActionMessage>
</div>
</section>
</div>
</div>

</template>

<script>
import Modal from '../Componnents/modal.vue'
import ActionMessage from '../Componnents/ActionMessage.vue'
export default {
    name: 'articleView',
    data(){
        return{
         title: '',
         author: '',
         articleContent: '',
         date: '',
         isModalVisible: '',
         showUpdateMessage: false
        }
    },
    components: {
    Modal,
    ActionMessage
  },
    methods:{
        async getArticleData(){
            try{
            const response = await this.$http.get(`http://localhost:3000/Articles/${this.$route.params.id}`)
            const createdAt = new Date(response.data.created_at)
            const updatedAt = new Date(response.data.updated_at)
            const response2 = await this.$http.get(`http://localhost:3000/Authors/${response.data.author}`)
            this.title = response.data.title
            this.author = response2.data.name
            this.articleContent = response.data.body
            this.date = createdAt.getTime() < updatedAt.getTime() ? updatedAt.toLocaleString() : createdAt.toLocaleString()
            }
            catch(err){
               
            }
        },
       async deleteArticle(index){
            if(confirm("Do you really want to delete?")){
      await this.$http.delete(`http://localhost:3000/Articles/${index}`).then(res => {this.closeModalAfterAction({type: 'delete', sucess: 'sucess'})}).catch(err => {this.closeModalAfterAction({type: 'delete', sucess: 'failure'})})
      
        }
    },
    closeModal(){
        this.isModalVisible = false;
    },
    showEditModal(){
        this.isModalVisible = true;
    },
    closeModalAfterAction(data){
        this.isModalVisible = false;
      this.showActionType = data.type
      this.sucess = data.sucess
        this.showUpdateMessage = true
      },
      closeActionModal() {
        this.showUpdateMessage = false;
        if(this.showActionType == 'update' && this.sucess == 'sucess'){
          this.$router.go(0);
        }
        else if(this.showActionType == 'delete' && this.sucess == 'sucess'){
            this.$router.push('/')
        }
        this.showActionType = ''
      this.sucess = ''
      }
},

    created(){
        this.getArticleData()
   
  }
}
</script>