<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
import postPage from './views/PostPage.vue'


export default {
  name: 'app',
  components:{
    postPage,
   
  },
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  },
  methods:{
    async post(){
    await this.$http.post("http://localhost:3000/Authors", { id: 2, name: "a", created_at:"a", updated_at:"b"})
    }
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 0px;
}

h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}
</style>
